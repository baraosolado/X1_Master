export default function Home() {
  return (
    <main className="flex items-center justify-center h-screen">
      <h1 className="text-3xl font-bold">X1 Master MVP</h1>
    </main>
  );
}